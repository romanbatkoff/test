<?
include ("include.php"); //подключение файла с классами
include ("sql.php"); //подключение файла с данными для подключения к бд
use UserClasses\ConnectdbHost; // подключаем класс соединения с бд из пространства имен
$connect_db=new ConnectdbHost($host,$user,$password);//объявляем подключение к бд
?>
<?

?>

<!--- Обработчик ajax запросов на редактирование списка пользователей-->
<?if($connect_db->connect()==true):?>
    <?
    $connection = new mysqli($host,$user,$password,$db_name);

    if (isset($_POST))
    {
        if (isset($_POST['sql_request_delete'])){
            $sql_remove=$_POST['sql_request_delete'];
            $sql='DELETE FROM '.$table_name.' WHERE ID='.'"'.$sql_remove.'"';
            $recordset = $connection->query($sql);
        }
        elseif (isset($_POST['sql_request_add'])) {
            $sql_add=$_POST['sql_request_add'];

            $sql_add=json_decode($sql_add, true);
            $sql="INSERT INTO ".$table_name." SET id='".$sql_add[ID]."', 
            name_user='".$sql_add[NAME]."', 
            patronymic='".$sql_add[PATRONYMIC]."', 
            last_name='".$sql_add[LAST_NAME]."',
            birthday='".$sql_add[BIRTHDAY]."', 
            email='".$sql_add[EMAIL]."', 
            login='".$sql_add[LOGIN]."', 
            password='".md5($sql_add[PASSWORD])."', 
            priority='".$sql_add[PRIORITY]."', 
            tel_num='".$sql_add[PHONE_NUMBER]."'";



            $recordset = $connection->query($sql);
        }
        elseif (isset($_POST['sql_request_update'])){
            $sql_update=$_POST['sql_request_update'];
            $sql_update=json_decode($sql_update, true);
            
            $sql="UPDATE ".$table_name." SET  name_user='".$sql_update[NAME]."',
            patronymic='".$sql_update[PATRONYMIC]."', 
            last_name='".$sql_update[LAST_NAME]."', 
            birthday='".$sql_update[BIRTHDAY]."',
            email='".$sql_update[EMAIL]."', 
            login='".$sql_update[LOGIN]."', 
            password='".$sql_update[PASSWORD]."', 
            priority='".$sql_update[PRIORITY]."', 
            tel_num='".$sql_update[PHONE_NUMBER]."' 
            WHERE id='".$sql_update[ID]."'";

            $recordset = $connection->query($sql);
        }

    }
    ?>
<?endif;?>



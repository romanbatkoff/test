<? 
$host=localhost; 
$user=dremax; 
$password=dremax; 
$db_name=sadasdaa; 
$table_name=asdasddsaaa; 
?>
<?php
include ("include.php"); //подключение файла с классами
include ("sql.php"); //подключение файла с данными для подключения к бд
use UserClasses\JQBoot; // подключаем класс добавления JQuery и Bootstrap из пространства имен
use UserClasses\ConnectdbHost; // подключаем класс соединения с бд из пространства имен
use UserClasses\AddDB; // подключаем класс добавления БД
use UserClasses\AddTable; // подключаем класс добавления таблицы
use UserClasses\AddSU; // подключаем класс добавления администратора
use UserClasses\PriorityUser; // подключаем класс добавления приоритета пользователю
use UserClasses\SessionUserInint; // подключаем проверки приоритета пользователя
$connect_db=new ConnectdbHost($host,$user,$password);//объявляем подключение к бд
include ("items.php");// подключаем файл получения массива из базы данных?>


<?error_reporting(0);
$addhead=new JQBoot(); //объявляем подключение JQuery bootstrap
$sessionstat= new SessionUserInint();// объявляем проверку сессии
$priority=$sessionstat->session();//получаем данные о приоритете пользователя
?>
<?
$sessionstat= new SessionUserInint();// объявляем проверку сессии
$priority=$sessionstat->session();//получаем данные о приоритете пользователя
?>
<?if ($priority!=false): // проверяем приоритет?>
    <?$priorityStatus=$priority;?>
<?else:?>
    <?$unknowUser="NA"; // если данные о статусе не получены устанавливаем приоритет неавторизован?>
    <?$user=new PriorityUser($unknowUser);?>
    <?$priorityStatus=$user->UserIs(); // присваеваем статус приоритета в сессии?>
<?endif;?>

<?if ($priorityStatus=="NA"):?> <!---проверяем статус если не автаризован то принемаем данные-->
<? if ($_POST[password]and$_POST[login]):?> <!---проверяем приняты ли данные-->

<?
 $login=$_POST[login];
 $password= md5($_POST[password]);
 ?>

<?foreach ($arItems as $arItem):?> <!---прогоняем массив, и проверяем есть ли пользователь с такими логином и паролем-->

<?if (($arItem[login]==$login)and($arItem[password]==$password)):?>
            <?$user=new PriorityUser($arItem[priority]);?>
            <?$priorityStatus=$user->UserIs(); // если пользователь обнаружен присваеваем его статус приоритета в сессии?>
            <script>document.location.href = "index.php";</script> <!---Автоматически переходим в режим редактирования-->
            <?else:?>
                <?$error="Ошибка в логине или пароле"; // если пользователь не обнаружен выдаем ошибку?>
<?endif;?>
<?endforeach;?>
<?elseif ( !($_POST[password]) and !($_POST[login])):?>
        <?$error="Вы не ввели данных для входа"; // если пользователь оставил пустыми поля выдаем ошибку?>
<?else:?>
           <?$error="Ошибка в логине или пароле";// если пользователь оставил пустыми одно из полей выдаем ошибку?>
<?endif;?>
<?endif;?>

<html>
<header>
    <!---подключаем jquery и bootstrap--->
    <?=$addhead->addtohead();?>
    <!---подключаем jquery и bootstrap--->
</header>
<body>
<div class="container">
<h1><?=$error;?></h1>
</div>
<div class="container">
<?if ($priorityStatus=="NA"):?>

<form action="auth.php" method="post">
    <div class="form-group">
        <label for="exampleInputEmail1">Логин</label>
        <input type="text" name="login" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Login">

    </div>
    <div class="form-group">
        <label for="exampleInputPassword1">Пароль</label>
        <input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
    </div>
    <div class="form-group form-check">
        <input type="checkbox" class="form-check-input" id="exampleCheck1">
        <label class="form-check-label" for="exampleCheck1">Запомнить</label>
    </div>
    <button type="submit" class="btn btn-primary">Войти</button>
</div>
</form>
<?elseif($priorityStatus=="SU"):?>
    <h2>Приветствую Вы зашли как Администратор</h2><a class="btn btn-primary" href="exit.php" role="button">Выйти</a>
<?elseif($priorityStatus=="US"):?>
    <h2>Приветствую Вы зашли как Пользователь</h2><a class="btn btn-primary" href="exit.php" role="button">Выйти</a>
<?endif;?>
</body>


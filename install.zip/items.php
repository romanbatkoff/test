
<?if($connect_db->connect()==true):?>
        <?
        $connection = new mysqli($host,$user,$password,$db_name);
        $query = "select * from ".$table_name;
        $result = $connection->query($query);
        $count=0;
        while($arItem = mysqli_fetch_assoc($result))
        {
            $arItems[$count]=$arItem;
            $count++;
        }
        ?>
<?endif;?>

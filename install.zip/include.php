<?php
namespace UserClasses; //добавляем файл в пространство имен


class JQBoot { //класс добавления JQuery и Bootstrap
    const lincs='<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.3.1/jquery.min.js"></script>
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap-theme.min.css">
    <script src="//netdna.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min.js"></script>';

    function addtohead (){
        return self::lincs;
    }
};




class ConnectdbHost { //класс подключения к БД
    public $host;
    public $user;
    public $password;
    public function __construct($host, $user, $password) {
        $this->host=$host;
        $this->user=$user;
        $this->password=$password;

    }
    function connect(){
        if(mysql_connect($this->host, $this->user, $this->password)!=true)
        {
            return false;
        }
        else
        {
            return true;
        }

    }

};

class AddDB { //класс добавления базы данных
    public $name;
    public function __construct($name) {$this->name=$name;}
    public function add_db_sql(){
        if( mysql_query("CREATE DATABASE ".$this->name)!=true)
        {
            return false;
        }
        else
        {
            return true;
        }
    }

};

class AddTable{ //класс добавления таблицы
    public $name_db;
    public $name_table;
    public $table_crate="
   (
       id VARCHAR(200) NOT NULL,
       last_name VARCHAR(200) NOT NULL,
       name_user VARCHAR(200) NOT NULL,
       patronymic VARCHAR(200) NOT NULL,
       birthday VARCHAR(200) NOT NULL,
       tel_num VARCHAR(200) NOT NULL,
       email VARCHAR(200) NOT NULL,
       login VARCHAR(200) NOT NULL,
       password VARCHAR(200) NOT NULL,
       priority VARCHAR(2) NOT NULL DEFAULT 'SU'
   )";
    public function __construct($name_db, $name_table){
        $this->name_db=$name_db;
        $this->name_table=$name_table;

    }
    public function table_into_bd(){

        $db=$this->name_db;
        $table_crate="CREATE Table ".$this->name_table." ".$this->table_crate;
        if ((mysql_select_db($db)!=true)||( mysql_query($table_crate)!=true))
        {
            return false;
        }
        else
        {
            return true;
        }


    }
}

class AddSU { //класс добавления администратора
    public $name_table;
    public $su_last_name;
    public $su_name;
    public $su_patronymic;
    public $su_birthday;
    public $su_tel_num;
    public $su_email;
    public $su_login;
    public $su_password;
    public function __construct($name_table,$su_last_name,$su_name,$su_patronymic, $su_birthday, $su_tel_num,$su_email,$su_login,$su_password)
    {
        $this->name_table=$name_table;
        $this->su_last_name=$su_last_name;
        $this->su_name=$su_name;
        $this->su_patronymic=$su_patronymic;
        $this->su_birthday=$su_birthday;
        $this->su_tel_num=$su_tel_num;
        $this->su_email=$su_email;
        $this->su_login=$su_login;
        $this->su_password=$su_password;
        $this->su_id=md5($su_login);
    }
    public function add_table_su(){
        $sql="INSERT INTO ".$this->name_table.
            " SET id='". $this->su_id."',
                  last_name='". $this->su_last_name."',
                  name_user='".$this->su_name."',
                  patronymic='".$this->su_patronymic."',
                  birthday='".$this->su_birthday."',
                  tel_num='".$this->su_tel_num."',
                  email='".$this->su_email."',
                  login='". $this->su_login."',
                  password='".$this->su_password."',
                  priority='SU'";
        if( mysql_query($sql)!=true)
        {
            return false;
        }
        else
        {
            return true;
        }

    }
}
class PriorityUser{ //класс устанавливающий приоритет
    public $priority;
    public function __construct($priority){
        $this->priority=$priority;

    }
    public function UserIs(){
        session_start();
        if($this->priority){
            $_SESSION['UserPriority']=$this->priority;
            return $_SESSION['UserPriority'];
        }
        else{
            return false;
        }
    }
}

class SessionUserInint { // класс проверки приоритета
    function session(){
        session_start();
        if($_SESSION['UserPriority']){
            return $_SESSION['UserPriority'];
        }
        else{
            false;
        }
    }
};




﻿<?php
include ("include.php"); //подключение файла с классами
use UserClasses\JQBoot; // подключаем класс добавления JQuery и Bootstrap из пространства имен
use UserClasses\ConnectdbHost; // подключаем класс соединения с бд из пространства имен
use UserClasses\AddDB; // подключаем класс добавления БД
use UserClasses\AddTable; // подключаем класс добавления таблицы
use UserClasses\AddSU; // подключаем класс добавления администратора
error_reporting(0); //отключаем вывод ошибок
$addhead=new JQBoot(); //объявляем подключение JQuery bootstrap


$bdconnect=$_POST;//получаем данные подключения бд
if ($bdconnect){ //проверяем пришли ли данные с формы
    //подключение к бд
    $host=$bdconnect[host]; // имя хоста
    $user=$bdconnect[user]; // администрато mysql
    $password = $bdconnect[password]; //пароль администратора mysql
    // создание бд и таблицы
    $db_name = $bdconnect[db_name]; // название базы данных
    $table_name=$bdconnect[table_name]; // название таблицы

    // данные администратора
    $su_last_name=$bdconnect[su_last_name]; // фамилия администратора
    $su_name=$bdconnect[su_name]; // имя администратора
    $su_patronymic=$bdconnect[su_patronymic]; // отчество администратора
    $su_birthday=$bdconnect[su_birthday]; // день рождения администратора
    $su_tel_num=$bdconnect[su_tel_num]; // телефонный номер администратора
    $su_email=$bdconnect[su_email]; // email администратора
    $su_login=$bdconnect[su_login]; // логин администратора
    $su_password=md5($bdconnect[su_password]); // зашифрованный пароль администратора

    $connect_db=new ConnectdbHost($host,$user,$password); //объявляем подключение к бд

    $add_db=new AddDB($db_name); //объявляем создание БД


    $add_table=new AddTable($db_name, $table_name); //объявляем создание таблицы
    $add_admin=new AddSU($table_name, $su_last_name, $su_name, $su_patronymic, $su_birthday, $su_tel_num, $su_email, $su_login, $su_password);//объявляем создание администратора
    //проверяем корректность исполнения. в случае успеха файл инсталяции удаляется и распаковывается архив
    if($connect_db->connect()==true){
        if($add_db->add_db_sql()==true){
            if($add_table->table_into_bd()==true){
                if($add_admin->add_table_su()==true){

                    $content_sql="<? \n".
                        "$"."host=".$host."; \n".
                        "$"."user=".$user."; \n".
                        "$"."password=".$password."; \n".
                        "$"."db_name=".$db_name."; \n".
                        "$"."table_name=".$table_name."; \n"
                        ."?>";
                    $fp = fopen("sql.php", "w");
                    fwrite($fp, $content_sql);
                    fclose($fp);
                    header("Location: index.php");

                    ?><script>document.location.href = "index.php";</script><?

                } else {$error_db="Ошибка установки БД и админстратора! Проверте входные данные1";}
            } else {$error_db="Ошибка установки БД и админстратора! Проверте входные данные2";}
        } else {$error_db="Ошибка установки БД и админстратора! Проверте входные данные3";}
    } else {$error_db="Ошибка установки БД и админстратора! Проверте входные данные4";} ;
  /* if(($connect_db->connect()==true)||($add_db->add_db_sql()==true)||($add_table->table_into_bd()==true)||($add_admin->add_table_su()==true))
    {

        $content_sql="<? \n".
            "$"."host=".$host."; \n".
            "$"."user=".$user."; \n".
            "$"."password=".$password."; \n".
            "$"."db_name=".$db_name."; \n".
            "$"."table_name=".$table_name."; \n"
            ."?>";
        $fp = fopen("sql.php", "w");
        fwrite($fp, $content_sql);
        fclose($fp);*/
       /* header("Location: index.php");*/

       /* unlink('install.php');*/
   /* }
   else {$error_db="Ошибка установки БД и админстратора! Проверте входные данные";}
    ;*/





};

?>
<html>
<header>
    <!---подключаем jquery и bootstrap--->
<?=$addhead->addtohead();?>
    <!---подключаем jquery и bootstrap--->
</header>
<body>
<div class="container">

    <form class="form-signin" role="form" action="install.php" method="post">
       <h2><?=$error_db;?></h2>
        <h2 class="form-signin-heading">Введите параметры подключения к серверу mysql</h2>
        <input type="text" name="host" pattern="^[A-Za-z0-9]+$" value="" class="form-control" placeholder="host" required autofocus>
        <input type="text" name="user" pattern="^[A-Za-z0-9]+$" value="" class="form-control" placeholder="пользователь" required>
        <input type="password" name="password" pattern="^[A-Za-z0-9]+$" value="" class="form-control" placeholder="пароль" required>
        <h2 class="form-signin-heading">Установка названия базы данных и рабочей таблицы</h2>
        <input type="text" name="db_name" pattern="^[A-Za-z0-9]+$" value="" class="form-control" placeholder="название базы" required>
        <input type="text" name="table_name" pattern="^[A-Za-z0-9]+$" value="" class="form-control" placeholder="название таблицы" required>
        <hr>

        <h2 class="form-signin-heading">Установите логин и пароль администратора</h2>
        <input type="text" name="su_last_name" value="" class="form-control" placeholder="Фамилия администратора" required>
        <input type="text" name="su_name" value="" class="form-control" placeholder="Имя администратора" required>
        <input type="text" name="su_patronymic" value="" class="form-control" placeholder="Отчество администратора" required>
        <input type="date" name="su_birthday" value="" class="form-control" placeholder="День рождения администратора" required>
        <input type="tel"  name="su_tel_num" pattern="[0-9]{4}-[0-9]{3}-[0-9]{4}"" value="" class="form-control" placeholder="Телефон администратора в формате 8ххх-ххх-хххх" required>
        <input type="email" name="su_email" value="" class="form-control" placeholder="email администратора" required>
        <input type="text" name="su_login" pattern="^[A-Za-z0-9]+$" value="" class="form-control" placeholder="Логин администратора" required>
        <input type="password" name="su_password" pattern="^[A-Za-z0-9]+$" value="" class="form-control" placeholder="Пароль" required>
        <button class="btn btn-lg btn-primary btn-block" type="submit">установить</button>
    </form>

</div> <!-- /container -->
</body>
</html>
$(function(){

    /*функция добавления полей*/
    $( ".add_unit" ).live( "click", function() {
        $('<tr class="user" id="">' +
            '<td class="name_user"><input class="form-control name_user" type="text" value=""></td>'+
            '<td class="last_name"><input class="form-control last_name" type="text" value=""></td>'+
            '<td class="patronymic"><input class="form-control patronymic" type="text" value=""></td>'+
            '<td class="birthday"><input class="form-control birthday" type="date" value=""></td>'+
            '<td class="tel_num"><input class="form-control tel_num" type="text" value=""></td>'+
            '<td class="email"><input class="form-control email" type="email" value=""></td>'+
            '<td class="login"><input class="form-control login" type="text" value=""></td>'+
            '<td class="password"><input class="form-control password" type="password" value=""></td>'+
            '<td class="priority"><select class="form-control priority">'+
            '<option selected="selected" value="US">US</option>'+
            '<option value="SU">SU</option></select></td>'+
            '<td><span class="btn btn-primary apply_remove" style="color: orangered;" href="">&#9940;</span>'+
            '<span class="btn btn-primary apply_edit" style="color: chartreuse;" href="">&#10004;</span></td>'+
            '</tr>'
        ).appendTo($(".contein"));
    });
    /*функция добавления полей*/
/*--------------------------------------------------------------------------------------------*/
    /*функция удаления*/
    $(".apply_remove").live('click',function () {
        var $unit=$(this).parent().parent();

        if(
            !$unit.attr("id")
        )
        {$unit.remove();}
        else{

            var sql_option=$unit.attr("id");

            $.post(
                "/ajax.php",
                {
                    sql_request_delete: sql_option
                },
                remove_unit
            );

            function remove_unit(data)
            {

                // Здесь мы получаем данные, отправленные сервером и выводим их на экран.
                $unit.remove();
                reload_block();
            }

        }
        ;



    });
    /*функция удаления*/
/*--------------------------------------------------------------------------------------------*/
    /*функция применить*/
    $(".apply_edit").live('click',function () {
        var $unit=$(this).parent().parent();
        var $name_user=$unit.children(".name_user").children("input").attr('value');
        var $last_name=$unit.children(".last_name").children("input").attr('value');
        var $patronymic=$unit.children(".patronymic").children("input").attr('value');
        var $birthday=$unit.children(".birthday").children("input").attr('value');
        var $tel_num=$unit.children(".tel_num").children("input").attr('value');
        var $email=$unit.children(".email").children("input").attr('value');
        var $login=$unit.children(".login").children("input").attr('value');
        var $password=$unit.children(".password").children("input").attr('value');
        var $priority=$unit.children(".priority").children("select").val();
        if (!$unit.attr("id")){
            if (
                (($name_user=="undefined")||($.trim($name_user)==""))
                ||(($last_name=="undefined")||($.trim($last_name)==""))
                ||(($patronymic=="undefined")||($.trim($patronymic)==""))
                ||(($birthday=="undefined")||($.trim($birthday)==""))
                ||(($tel_num=="undefined")||($.trim($tel_num)==""))
                ||(($email=="undefined")||($.trim($email)==""))
                ||(($login=="undefined")||($.trim($login)==""))
                ||(($password=="undefined")||($.trim($password)==""))
                ||(($priority=="undefined")||($.trim($priority)==""))
            ){
                alert("не должно быть пустых полей");
            } else {

                var idgen = "";
                var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890";

                for( var i=0; i < 20; i++ )
                    idgen += possible.charAt(Math.floor(Math.random() * possible.length));
                $unit.attr("id",idgen);

               var user_add = {
                    ID: idgen,
                    NAME: $name_user,
                    LAST_NAME: $last_name,
                    PATRONYMIC: $patronymic,
                    BIRTHDAY: $birthday,
                    PHONE_NUMBER: $tel_num,
                    EMAIL: $email,
                    LOGIN: $login,
                    PASSWORD: $password,
                    PRIORITY: $priority
                };
                var user_add = JSON.stringify(user_add);

                $.post(
                    "/ajax.php",
                    {
                        sql_request_add: user_add

                    },
                    add_unit
                );
                function add_unit(data)
                {
                    // Здесь мы получаем данные, отправленные сервером и выводим их на экран.

                    alert('Элемент добавлен');
                    reload_block();
                }


            }
        } else {
            var sql_option=$unit.attr("id");
            if (
                (($name_user=="undefined")||($.trim($name_user)==""))
                ||(($last_name=="undefined")||($.trim($last_name)==""))
                ||(($patronymic=="undefined")||($.trim($patronymic)==""))
                ||(($birthday=="undefined")||($.trim($birthday)==""))
                ||(($tel_num=="undefined")||($.trim($tel_num)==""))
                ||(($email=="undefined")||($.trim($email)==""))
                ||(($login=="undefined")||($.trim($login)==""))
                ||(($password=="undefined")||($.trim($password)==""))
                ||(($priority=="undefined")||($.trim($priority)==""))
            ){
                alert("не должно быть пустых полей");
            } else {

                var user_updete = {
                    ID: sql_option,
                    NAME: $name_user,
                    LAST_NAME: $last_name,
                    PATRONYMIC: $patronymic,
                    BIRTHDAY: $birthday,
                    PHONE_NUMBER: $tel_num,
                    EMAIL: $email,
                    LOGIN: $login,
                    PASSWORD: $password,
                    PRIORITY: $priority
                };

                var user_updete = JSON.stringify(user_updete);

                $.post(
                    "/ajax.php",
                    {
                        sql_request_update: user_updete

                    },
                    updete_unit
                );

                function updete_unit(data)
                {

                    // Здесь мы получаем данные, отправленные сервером и выводим их на экран.
                    
                    alert('Элемент изменен');
                    reload_block();
                }

            }


        };

    });
    /*функция применить*/
});
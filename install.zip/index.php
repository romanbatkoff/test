<?php
include ("include.php"); //подключение файла с классами
include ("sql.php"); //подключение файла с данными для подключения к бд
use UserClasses\JQBoot; // подключаем класс добавления JQuery и Bootstrap из пространства имен
use UserClasses\ConnectdbHost; // подключаем класс соединения с бд из пространства имен
use UserClasses\AddDB; // подключаем класс добавления БД
use UserClasses\AddTable; // подключаем класс добавления таблицы
use UserClasses\AddSU; // подключаем класс добавления администратора
use UserClasses\PriorityUser; // подключаем класс добавления приоритета пользователю
use UserClasses\SessionUserInint; // подключаем проверки приоритета пользователя
$connect_db=new ConnectdbHost($host,$user,$password);//объявляем подключение к бд
include ("items.php");// подключаем файл получения массива из базы данных?>


<?error_reporting(0);
$addhead=new JQBoot(); //объявляем подключение JQuery bootstrap
$sessionstat= new SessionUserInint();// объявляем проверку сессии
$priority=$sessionstat->session();//получаем данные о приоритете пользователя
?>
<?if ($priority!=false): // проверяем приоритет?>
<?$priorityStatus=$priority;?>
<?else:?>
<?$unknowUser="NA"; // если данные о статусе не получены устанавливаем приоритет неавторизован?>
<?$user=new PriorityUser($unknowUser);?>
<?$priorityStatus=$user->UserIs(); // присваеваем статус приоритета в сессии?>
<?endif;?>

<html>
<header>
    <!---подключаем jquery и bootstrap--->
    <?=$addhead->addtohead();?>
    <!---подключаем jquery и bootstrap--->

</header>
<body>


<?if ($priorityStatus!="SU"):// проверяем приоритет если это не администратор просто выводим список с данными указывая приоритет пользователя ?>
    <div class="container">
        <?if ($priorityStatus=="US"):?>
        <h2>Приветствую Вы зашли как Пользователь</h2><a class="btn btn-primary" href="exit.php" role="button">Выйти</a>
        <?else:?>
        <h2>Вы не автрризованны</h2><a class="btn btn-primary" href="auth.php" role="button">Авторизоваться</a>
        <?endif;?>
    </div>
<div class="container">

    <table class="table">
        <thead>
        <tr>
            <th scope="col">№</th>
            <th scope="col">Фамилия</th>
            <th scope="col">Имя</th>
            <th scope="col">Отчество</th>
            <th scope="col">Дата рождения</th>
            <th scope="col">Номер</th>
            <th scope="col">Email</th>
        </tr>
        </thead>
        <tbody>
        <?$numitem=1;?>
<?foreach ($arItems as $arUnit):?>
    <tr>
        <th scope="row"><?=$numitem;?></th>
        <td><?=$arUnit[last_name];?></td>
        <td><?=$arUnit[name_user];?></td>
        <td><?=$arUnit[patronymic];?></td>
        <td><?=$arUnit[birthday];?></td>
        <td><?=$arUnit[tel_num];?></td>
        <td><?=$arUnit[email];?></td>
    </tr>
<?$numitem++;?>
<?endforeach;?>
        </tbody>
    </table>

</div> <!-- /container -->
<?else: // проверяем приоритет если это администратор выводим список с возможностью редактирования ?>
    <div class="container">
        <h2>Приветствую! Вы зашли как Администратор</h2><a class="btn btn-primary" href="exit.php" role="button">Выйти</a>
    </div>
<div class="container">
    <table class="table">

    <thead>
    <tr>

        <th scope="col">Имя</th>
        <th scope="col">Фамилия</th>
        <th scope="col">Отчество</th>
        <th scope="col">Дата рождения</th>
        <th scope="col">Номер</th>
        <th scope="col">Email</th>
        <th scope="col">login</th>
        <th scope="col">password</th>
        <th scope="col">приоритет</th>
        <th scope="col">редактирование</th>
    </tr>
    </thead>
        <tbody class="contein">
        <?foreach ($arItems as $arUnit):?>
    <tr class="user" id="<?=$arUnit[id];?>">

        <td class="name_user"><input class="form-control" type="text" value="<?=$arUnit[name_user];?>"></td>
        <td class="last_name"><input class="form-control" type="text" value="<?=$arUnit[last_name];?>"></td>
        <td class="patronymic"><input class="form-control" type="text" value="<?=$arUnit[patronymic];?>"></td>
        <td class="birthday"><input class="form-control" type="date" value="<?=$arUnit[birthday];?>"></td>
        <td class="tel_num"><input class="form-control" type="text" value="<?=$arUnit[tel_num];?>"></td>
        <td class="email"><input class="form-control" type="email" value="<?=$arUnit[email];?>"></td>
        <td class="login"><input class="form-control" type="text" value="<?=$arUnit[login];?>"></td>
        <td class="password"><input class="form-control" type="password" value="<?=$arUnit[password];?>"></td>
        <td class="priority"><select class="form-control">
                <option <?if ($arUnit[priority]=="US"): ?> selected="selected" <?endif;?>value="US">US</option>
                <option <?if ($arUnit[priority]=="SU"): ?> selected="selected" <?endif;?> value="SU">SU</option>
            </select></td>
        <td><span class="btn btn-primary apply_remove" title="удалить" style="color: orangered;" href="">&#9940;</span><span class="btn btn-primary apply_edit" title="применить" style="color: chartreuse;" href="">&#10004;</span></td>
    </tr>


        <?endforeach;?>

        </tbody>
        <tr>
            <td><span href="" class="btn btn-primary add_unit" >Добавить</span></td>
        </tr>
    </table>
</div>
<?endif;?>
</body>
<script src="ajaxpost.js"></script>
</html>